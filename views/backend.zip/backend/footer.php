<footer class="main-footer">
         <div class="float-right d-none d-sm-block">
            <b>Version</b> 3.2.0
         </div>
         <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights
         reserved.
      </footer>
   </div>
   <script src="../public/jquery/jquery-3.7.0.min.js"></script>
   <script src="../public/datatables/js/dataTables.min.js"></script>
   <script src="../public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="../public/dist/js/adminlte.min.js"></script>
   <script>
      $(document).ready(function () {
         $('#mytable').DataTable();
      });
   </script>
</body>

</html>